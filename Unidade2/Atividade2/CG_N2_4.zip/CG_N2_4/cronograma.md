# Cronograma

<!-- [Cronograma turma Matutino](cg_cronograma_mat.pdf "Cronograma turma Matutino")  -->

[Cronograma turma Noturno](cronograma.pdf "Cronograma turma Noturno")  

## Eventos

[Semana Acadêmica](https://github.com/dalton-reis/dalton-reis/blob/main/_._/semanaAcademica.md "Semana Acadêmica")  

<!-- [SEMINCO: BCC e SIS](<> "SEMINCO: BCC e SIS")  -->
<!-- [Escola Regional de Engenharia de Software - ERES](https://eres-sbc-br.github.io/eres2022/ "Escola Regional de Engenharia de Software - ERES")  -->
