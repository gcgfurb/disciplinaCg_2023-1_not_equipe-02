#define CG_Gizmo  // debugar gráfico.
#define CG_OpenGL // render OpenGL.
//#define CG_DirectX // render DirectX.
// #define CG_Privado // código do professor.

using CG_Biblioteca;
using OpenTK.Graphics.OpenGL4;

namespace gcgcg
{
internal class Spline : Objeto
{
    private double[,] matrizBezier;
    private int ptoSelecionado, splineQtdPto;
    private readonly int splineQtdPtoMax;
    private Ponto[] ptosControle;
    private Poligono ctrlPoliedro;

    public Spline(Objeto paiRef) : base(paiRef)
    {
    ptosControle = new Ponto[4];
    splineQtdPtoMax = splineQtdPto = 8;
    matrizBezier = new double[11, 4];
    
    PontosControle();
    CtrlPoliedro();
    PrimitivaTipo = PrimitiveType.LineStrip;
    MatrizBezier();

    for (int i = 0; i <= splineQtdPto; i++)
    {
        PontosAdicionar(new Ponto4D());
    }
    
    Atualizar();
    }

     private void PontosControle()
    {
    var pontos = new[]
    {
        new Ponto4D(0.5, -0.5, 0.0, 1.0),
        new Ponto4D(0.5, 0.5, 0.0, 1.0),
        new Ponto4D(-0.5, 0.5, 0.0, 1.0),
        new Ponto4D(-0.5, -0.5, 0.0, 1.0)
    };
    
    for (int i = 0; i < pontos.Length; i++)
    {
        var ponto = new Ponto(this, pontos[i]);
        this.ptosControle[i] = ponto;
        ponto.Rotulo = base.rotulo = Utilitario.charProximo(base.rotulo);
        base.FilhoAdicionar(ponto);
        ponto.ObjetoAtualizar();
    }
    }

    private void MatrizBezier()
    {
    int num = 0;
    double inc = 1.0 / ((double)this.splineQtdPto);
    for (double i = 0.0; i <= 1.0; i += inc)
    {
        double umMenosI = 1.0 - i;
        this.matrizBezier[num, 0] = umMenosI * umMenosI * umMenosI;
        this.matrizBezier[num, 1] = 3.0 * i * umMenosI * umMenosI;
        this.matrizBezier[num, 2] = 3.0 * i * i * umMenosI;
        this.matrizBezier[num, 3] = i * i * i;
        num++;
    }
    }   

    private void CtrlPoliedro()
    {
    this.ctrlPoliedro = new Poligono(this)
    {
        PrimitivaTipo = PrimitiveType.LineStrip
    };
    this.ctrlPoliedro.PontosAdicionar(this.ptosControle[0].PontosId(0)); 
    this.ctrlPoliedro.PontosAdicionar(this.ptosControle[1].PontosId(0));
    this.ctrlPoliedro.PontosAdicionar(this.ptosControle[2].PontosId(0));
    this.ctrlPoliedro.PontosAdicionar(this.ptosControle[3].PontosId(0));
    base.FilhoAdicionar(this.ctrlPoliedro);
    this.ctrlPoliedro.Rotulo = base.rotulo = Utilitario.charProximo(base.rotulo);
    this.ctrlPoliedro.ObjetoAtualizar();
    }

     public void SplineQtdPto(int inc)
    {
    int splineQtdPto = (inc >= 0 || this.splineQtdPto <= 0) ? this.splineQtdPto : (this.splineQtdPto += inc);
    this.splineQtdPto = (inc <= 0 || this.splineQtdPto >= this.splineQtdPtoMax) ? splineQtdPto : (this.splineQtdPto += inc);
    this.MatrizBezier();
    this.Atualizar();
    }

    public void Atualizar()
    {
        Ponto4D pontod = new Ponto4D(this.ptosControle[0].PontosId(0));
        Ponto4D pontod2 = new Ponto4D(this.ptosControle[1].PontosId(0));
        Ponto4D pontod3 = new Ponto4D(this.ptosControle[2].PontosId(0));
        Ponto4D pontod4 = new Ponto4D(this.ptosControle[3].PontosId(0));
        double x = 0.0;
        double y = 0.0;
        for (int i = 0; i <= this.splineQtdPto; i++)
        {
            x = (((pontod.X * this.matrizBezier[i, 0]) + (pontod2.X * this.matrizBezier[i, 1])) + (pontod3.X * this.matrizBezier[i, 2])) + (pontod4.X * this.matrizBezier[i, 3]);
            y = (((pontod.Y * this.matrizBezier[i, 0]) + (pontod2.Y * this.matrizBezier[i, 1])) + (pontod3.Y * this.matrizBezier[i, 2])) + (pontod4.Y * this.matrizBezier[i, 3]);
            base.PontosAlterar(new Ponto4D(x, y, 0.0, 1.0), i);
        }
        base.ObjetoAtualizar();
    }

    public void AtualizarSpline(Ponto4D ptoInc, bool proximo = false)
    {
    if (proximo)
    {
        this.ptoSelecionado = (this.ptoSelecionado + 1) % 4;
    }
    this.ptosControle[this.ptoSelecionado].PontosAlterar(this.ptosControle[this.ptoSelecionado].PontosId(0) + ptoInc, 0);
    this.ptosControle[this.ptoSelecionado].ObjetoAtualizar();
    this.ctrlPoliedro.PontosAlterar(this.ptosControle[this.ptoSelecionado].PontosId(0), this.ptoSelecionado);
    this.ctrlPoliedro.ObjetoAtualizar();
    this.Atualizar();
    }

    public override string ToString()
    {
        string[] textArray1 = new string[] { "__ Objeto Spline _ Tipo: ", (string) base.PrimitivaTipo.ToString(), " _ Tamanho: ", (string) ((float) base.PrimitivaTamanho).ToString(), "\n" };
        return (string.Concat((string[]) textArray1) + base.ImprimeToString());
    }
}
}

