# Equipe

Para desenvolver as atividades da disciplina de Computação Gráfica favor utilizar as respectivas pastas para postar os trabalhos de cada unidade.  

Alunos:  

## [Atividades da Unidade 1](Unidade1/Atividade1 "Atividades da Unidade 1")

## [Atividades da Unidade 2](Unidade2/Atividade2 "Atividades da Unidade 2")  

## [Atividades da Unidade 3](Unidade3/Atividade3 "Atividades da Unidade 3")  

## [Atividades da Unidade 4](Unidade4/Atividade4 "Atividades da Unidade 4")  
