﻿#define CG_Gizmo  // debugar gráfico.
#define CG_OpenGL // render OpenGL.
// #define CG_DirectX // render DirectX.
#define CG_Privado // código do professor.

using CG_Biblioteca;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.GraphicsLibraryFramework;
using OpenTK.Windowing.Desktop;
using System;
using OpenTK.Mathematics;
using System.Collections.Generic;

//FIXME: padrão Singleton

namespace gcgcg
{
  public class Mundo : GameWindow
  {
    private Objeto mundo;
    private char rotuloNovo = '?';
    private Objeto objetoSelecionado;
    private Objeto objetoNovo; // Novo

    private readonly float[] _sruEixos =
    {
      -0.5f,  0.0f,  0.0f, /* X- */      0.5f,  0.0f,  0.0f, /* X+ */
       0.0f, -0.5f,  0.0f, /* Y- */      0.0f,  0.5f,  0.0f, /* Y+ */
       0.0f,  0.0f, -0.5f, /* Z- */      0.0f,  0.0f,  0.5f, /* Z+ */
    };

    private int _vertexBufferObject_sruEixos;
    private int _vertexArrayObject_sruEixos;
    private int _vertexBufferObject_bbox; //Novo
    private int _vertexArrayObject_bbox; //Novo
    private Shader _shaderBranca;
    private Shader _shaderVermelha;
    private Shader _shaderVerde;
    private Shader _shaderAzul;
    private Shader _shaderCiano;
    private Shader _shaderMagenta;
    private Shader _shaderAmarela;

    public Mundo(GameWindowSettings gameWindowSettings, NativeWindowSettings nativeWindowSettings)
           : base(gameWindowSettings, nativeWindowSettings)
    {
      mundo = new Objeto(null, ref rotuloNovo);
    }

    private void Diretivas()
    {
#if DEBUG
      Console.WriteLine("Debug version");
#endif      
#if RELEASE
    Console.WriteLine("Release version");
#endif      
#if CG_Gizmo      
      Console.WriteLine("#define CG_Gizmo  // debugar gráfico.");
#endif
#if CG_OpenGL      
      Console.WriteLine("#define CG_OpenGL // render OpenGL.");
#endif
#if CG_DirectX      
      Console.WriteLine("#define CG_DirectX // render DirectX.");
#endif
#if CG_Privado      
      Console.WriteLine("#define CG_Privado // código do professor.");
#endif
      Console.WriteLine("__________________________________ \n");
    }

    protected override void OnLoad()
    {
      base.OnLoad();

      Diretivas();

      GL.ClearColor(0.0f, 0.0f, 0.0f, 1.0f);

      #region Cores
      _shaderBranca = new Shader("Shaders/shader.vert", "Shaders/shaderBranca.frag");
      _shaderVermelha = new Shader("Shaders/shader.vert", "Shaders/shaderVermelha.frag");
      _shaderVerde = new Shader("Shaders/shader.vert", "Shaders/shaderVerde.frag");
      _shaderAzul = new Shader("Shaders/shader.vert", "Shaders/shaderAzul.frag");
      _shaderCiano = new Shader("Shaders/shader.vert", "Shaders/shaderCiano.frag");
      _shaderMagenta = new Shader("Shaders/shader.vert", "Shaders/shaderMagenta.frag");
      _shaderAmarela = new Shader("Shaders/shader.vert", "Shaders/shaderAmarela.frag");
      #endregion

      #region Eixos: SRU  
      _vertexBufferObject_sruEixos = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject_sruEixos);
      GL.BufferData(BufferTarget.ArrayBuffer, _sruEixos.Length * sizeof(float), _sruEixos, BufferUsageHint.StaticDraw);
      _vertexArrayObject_sruEixos = GL.GenVertexArray();
      GL.BindVertexArray(_vertexArrayObject_sruEixos);
      GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);
      GL.EnableVertexAttribArray(0);
      #endregion

    }

    protected override void OnRenderFrame(FrameEventArgs e)
    {
      base.OnRenderFrame(e);
      
      GL.Clear(ClearBufferMask.ColorBufferBit);
      mundo.Desenhar(new Transformacao4D());
#if CG_Gizmo
      Gizmo_Sru3D();
#endif
      Gizmo_BBox();
      SwapBuffers();
    }

    protected override void OnUpdateFrame(FrameEventArgs e)
    {
      base.OnUpdateFrame(e);
      KeyboardState keyboardState = KeyboardState;
      if (keyboardState.IsKeyDown(Keys.Escape))
        Close();
      if (keyboardState.IsKeyPressed(Keys.Space))
      {
        if (objetoSelecionado == null)
          objetoSelecionado = mundo;
          objetoSelecionado = mundo.GrafocenaBuscaProximo(objetoSelecionado);
      }
      if (keyboardState.IsKeyPressed(Keys.F))
        mundo.GrafocenaImprimir("");
      if (keyboardState.IsKeyPressed(Keys.T) && objetoSelecionado != null)
        Console.WriteLine(objetoSelecionado.ToString());
      if (keyboardState.IsKeyPressed(Keys.M) && objetoSelecionado != null)
        objetoSelecionado.MatrizImprimir();
      if (keyboardState.IsKeyPressed(Keys.I) && objetoSelecionado != null)
        objetoSelecionado.MatrizAtribuirIdentidade();
      if (keyboardState.IsKeyPressed(Keys.N) && objetoSelecionado != null)
        objetoSelecionado = (Objeto) null;
      if (keyboardState.IsKeyPressed(Keys.Enter) && objetoNovo != null)
      {
        objetoSelecionado = objetoNovo;
        objetoNovo = (Objeto) null;
      }
      if (keyboardState.IsKeyPressed(Keys.D) && objetoSelecionado != null)
      {
        objetoSelecionado.ObjetoRemover();
        objetoSelecionado = (Objeto) null;
      }
      if (keyboardState.IsKeyDown(Keys.V) && objetoSelecionado != null)
      {
        Ponto4D ponto4D = Utilitario.NDC_TelaSRU(Size.X, Size.Y, new Ponto4D((double) MousePosition.X, (double) MousePosition.Y));
        int posicao = objetoSelecionado.EncontrarPontoProximo(ponto4D, false);
        if (posicao > -1)
          objetoSelecionado.PontosAlterar(ponto4D, posicao);
      }
      if (keyboardState.IsKeyPressed(Keys.E) && objetoSelecionado != null)
        objetoSelecionado.EncontrarPontoProximo(Utilitario.NDC_TelaSRU(Size.X, Size.Y, new Ponto4D((double) MousePosition.X, (double) MousePosition.Y)));
      if (keyboardState.IsKeyPressed(Keys.P) && objetoSelecionado != null)
      {
        objetoSelecionado.PrimitivaTipo = objetoSelecionado.PrimitivaTipo != PrimitiveType.LineLoop ? PrimitiveType.LineLoop : PrimitiveType.LineStrip;
        objetoSelecionado.ObjetoAtualizar();
      }
      if (keyboardState.IsKeyPressed(Keys.R) && objetoSelecionado != null)
        objetoSelecionado.shaderCor = _shaderVermelha;
      if (keyboardState.IsKeyPressed(Keys.G) && objetoSelecionado != null)
        objetoSelecionado.shaderCor = _shaderVerde;
      if (keyboardState.IsKeyPressed(Keys.B) && objetoSelecionado != null)
        objetoSelecionado.shaderCor = _shaderAzul;
      if (keyboardState.IsKeyPressed(Keys.Left) && objetoSelecionado != null)
        objetoSelecionado.MatrizTranslacaoXYZ(-0.05, 0.0, 0.0);
      if (keyboardState.IsKeyPressed(Keys.Right) && objetoSelecionado != null)
        objetoSelecionado.MatrizTranslacaoXYZ(0.05, 0.0, 0.0);
      if (keyboardState.IsKeyPressed(Keys.Up) && objetoSelecionado != null)
        objetoSelecionado.MatrizTranslacaoXYZ(0.0, 0.05, 0.0);
      if (keyboardState.IsKeyPressed(Keys.Down) && objetoSelecionado != null)
        objetoSelecionado.MatrizTranslacaoXYZ(0.0, -0.05, 0.0);
      if (keyboardState.IsKeyPressed(Keys.Home) && objetoSelecionado != null)
        objetoSelecionado.MatrizEscalaXYZBBox(0.5, 0.5, 0.5);
      if (keyboardState.IsKeyPressed(Keys.End) && objetoSelecionado != null)
        objetoSelecionado.MatrizEscalaXYZBBox(2.0, 2.0, 2.0);
      if (keyboardState.IsKeyPressed(Keys.D3) && objetoSelecionado != null)
        objetoSelecionado.MatrizRotacaoZBBox(10.0);
      if (keyboardState.IsKeyPressed(Keys.D4) && objetoSelecionado != null)
        objetoSelecionado.MatrizRotacaoZBBox(-10.0);
      if (MouseState.IsButtonPressed(MouseButton.Button2)) /////////////////////
      {
        Ponto4D pto = Utilitario.NDC_TelaSRU(Size.X, Size.Y, new Ponto4D((double) MousePosition.X, (double) MousePosition.Y));
        if (objetoNovo == null)
        {
          List<Ponto4D> pontosPoligono = new List<Ponto4D>();
          pontosPoligono.Add(pto);
          pontosPoligono.Add(pto);
          if (objetoSelecionado == null)
          {
            objetoNovo = (Objeto) new Poligono(mundo, ref rotuloNovo, pontosPoligono);
          }
          else
          {
            objetoNovo = (Objeto) new Poligono(objetoSelecionado, ref rotuloNovo, pontosPoligono);
            objetoSelecionado = (Objeto) null;
          }
        }
        else
          objetoNovo.PontosAdicionar(pto);
      }
      if (MouseState.IsButtonDown(MouseButton.Button2) && objetoNovo != null)
        objetoNovo.PontosAlterar(Utilitario.NDC_TelaSRU(Size.X, Size.Y, new Ponto4D((double) MousePosition.X, (double) MousePosition.Y)), 0);
      if (!MouseState.IsButtonDown(MouseButton.Button1))
        return;
      Ponto4D ptoClique = Utilitario.NDC_TelaSRU(Size.X, Size.Y, new Ponto4D((double) MousePosition.X, (double) MousePosition.Y));
      objetoSelecionado = (Objeto) null;
      mundo.ScanLine(ptoClique, ref objetoSelecionado);
    }

    protected override void OnResize(ResizeEventArgs e)
    {
      base.OnResize(e);

      GL.Viewport(0, 0, Size.X, Size.Y);
    }

    protected override void OnUnload()
    {
      mundo.OnUnload();

      GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
      GL.BindVertexArray(0);
      GL.UseProgram(0);

      GL.DeleteBuffer(_vertexBufferObject_sruEixos);
      GL.DeleteVertexArray(_vertexArrayObject_sruEixos);

      GL.DeleteProgram(_shaderBranca.Handle);
      GL.DeleteProgram(_shaderVermelha.Handle);
      GL.DeleteProgram(_shaderVerde.Handle);
      GL.DeleteProgram(_shaderAzul.Handle);
      GL.DeleteProgram(_shaderCiano.Handle);
      GL.DeleteProgram(_shaderMagenta.Handle);
      GL.DeleteProgram(_shaderAmarela.Handle);

      base.OnUnload();
    }
#if CG_Gizmo
    private void Gizmo_Sru3D()
    {
      Matrix4 identity = Matrix4.Identity;
      GL.BindVertexArray(_vertexArrayObject_sruEixos);
      // EixoX
      _shaderVermelha.SetMatrix4("transform", identity);
      _shaderVermelha.Use();
      GL.DrawArrays(PrimitiveType.Lines, 0, 2);
      // EixoY
      _shaderVerde.SetMatrix4("transform", identity);
      _shaderVerde.Use();
      GL.DrawArrays(PrimitiveType.Lines, 2, 2);
      // EixoZ
      _shaderAzul.SetMatrix4("transform", identity);
      _shaderAzul.Use();
      GL.DrawArrays(PrimitiveType.Lines, 4, 2);
    }
#endif
    private void Gizmo_BBox()
    {
    if (objetoSelecionado == null)
      return;

    float minX = (float)objetoSelecionado.Bbox().obterMenorX;
    float minY = (float)objetoSelecionado.Bbox().obterMenorY;
    float maxX = (float)objetoSelecionado.Bbox().obterMaiorX;
    float maxY = (float)objetoSelecionado.Bbox().obterMaiorY;

    float[] data = new float[]
    {
        minX, minY, 0,
        maxX, minY, 0,
        maxX, maxY, 0,
        minX, maxY, 0
    };

    _vertexBufferObject_bbox = GL.GenBuffer();
    GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject_bbox);
    GL.BufferData(BufferTarget.ArrayBuffer, data.Length * sizeof(float), data, BufferUsageHint.StaticDraw);

    _vertexArrayObject_bbox = GL.GenVertexArray();
    GL.BindVertexArray(_vertexArrayObject_bbox);

    GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);
    GL.EnableVertexAttribArray(0);

    Matrix4 identity = Matrix4.Identity;

    _shaderAmarela.Use();
    _shaderAmarela.SetMatrix4("transform", identity);

    GL.DrawArrays(PrimitiveType.LineLoop, 0, 4);
    }
  }
}
