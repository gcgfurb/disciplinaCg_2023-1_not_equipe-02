﻿namespace GrafoCena
{
  public static class Program
  {
    private static void Main()
    {
      Console.WriteLine("Main");
      Mundo mundo = new Mundo();


    }
  }

}
