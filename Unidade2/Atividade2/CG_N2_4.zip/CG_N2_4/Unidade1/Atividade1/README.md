# Unidade 1: Introdução - atividade

Os assuntos serão sorteados pelo professor e enviados para cada equipe, então não esqueça de definir sua equipe no AVA3.

O que deve ser feito:

- prepare uma apresentação de no máximo 10 minutos
- escolha a melhor forma de apresentar o conteúdo usando slides, animações, vídeos, exemplos práticos etc.
- em caso de dúvida, converse com o professor.

## Gabarito

![Gabarito](atividadeGabarito.png "Gabarito")  

----------

## ⏭ [Unidade 2)](../../Unidade2/README.md "Unidade 2")  
