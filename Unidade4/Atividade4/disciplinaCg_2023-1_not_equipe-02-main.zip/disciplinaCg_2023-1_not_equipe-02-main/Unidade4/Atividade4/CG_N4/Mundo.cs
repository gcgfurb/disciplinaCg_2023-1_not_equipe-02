﻿#define CG_Gizmo  // debugar gráfico.
#define CG_OpenGL // render OpenGL.
// #define CG_DirectX // render DirectX.
// #define CG_Privado // código do professor.

using CG_Biblioteca;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.GraphicsLibraryFramework;
using OpenTK.Windowing.Desktop;
using System;
using OpenTK.Mathematics;
using System.Collections.Generic;


//FIXME: padrão Singleton

namespace gcgcg
{
  public class Mundo : GameWindow
  {
    Objeto mundo;
    private char rotuloNovo = '?';
    private Objeto objetoSelecionado = null;
    private bool _firstMove = true;
    private Vector2 _lastPos;

    private readonly float[] _sruEixos =
    {
      -0.5f,  0.0f,  0.0f, /* X- */      0.5f,  0.0f,  0.0f, /* X+ */
       0.0f, -0.5f,  0.0f, /* Y- */      0.0f,  0.5f,  0.0f, /* Y+ */
       0.0f,  0.0f, -0.5f, /* Z- */      0.0f,  0.0f,  0.5f  /* Z+ */
    };
    private Shader _shaderBranca;
    private Shader _shaderVermelha;
    private Shader _shaderVerde;
    private Shader _shaderAzul;
    private Shader _shaderCiano;
    private Shader _shaderMagenta;
    private Shader _shaderAmarela;
    private int _vertexBufferObject_sruEixos;
    private int _vertexArrayObject_sruEixos;
    private float xAnterior;
    double anguloHorizontal = -90;
    private float yAnterior;
    double anguloVertical = 0;
    private float xAtual;
    private float yAtual;
    private Shader _shader1;
    private Shader _shader2;
    private Shader _shader3;
    private Shader _shader4;
    private Shader _shader5;
    private Shader _shader6;
    private Texture _texture1;
    private Texture _texture2;
    private Texture _texture3;
    private Texture _texture4;
    private Texture _texture5;
    private Texture _texture6;
    private int _vertexBufferObject_texture;
    private int _vertexArrayObject_texture;
    private int _elementBufferObject_texture;
    private int _vertexBufferObject_texture2;
    private int _vertexArrayObject_texture2;
    private int _elementBufferObject_texture2;
    private int _vertexBufferObject_texture3;
    private int _vertexArrayObject_texture3;
    private int _elementBufferObject_texture3;
    private int _vertexBufferObject_texture4;
    private int _vertexArrayObject_texture4;
    private int _elementBufferObject_texture4;
    private int _vertexBufferObject_texture5;
    private int _vertexArrayObject_texture5;
    private int _elementBufferObject_texture5;
    private int _vertexBufferObject_texture6;
    private int _vertexArrayObject_texture6;
    private int _elementBufferObject_texture6;
    private readonly float[] _vertices = {
        -0.3f, -0.3f, 0.3f, 0.0f, 0.0f, // face 1
        0.3f, -0.3f, 0.3f, 1.0f, 0.0f,
        0.3f, 0.3f, 0.3f, 1.0f, 1.0f,
        -0.3f, 0.3f, 0.3f, 0.0f, 1.0f,
    };

    private readonly float[] _vertices2 = {
        -0.3f, -0.3f, -0.3f, 0.0f, 0.0f, // face 2
        0.3f, -0.3f, -0.3f, 1.0f, 0.0f,
        0.3f, 0.3f, -0.3f, 1.0f, 1.0f,
        -0.3f, 0.3f, -0.3f, 0.0f, 1.0f,
    };

    private readonly float[] _vertices3 = {
        -0.3f, 0.3f, 0.3f, 0.0f, 0.0f, // face 3
        0.3f, 0.3f, -0.3f, 1.0f, 1.0f,
        0.3f, 0.3f, 0.3f, 1.0f, 0.0f,
        -0.3f, 0.3f, -0.3f, 0.0f, 1.0f,
    };

    private readonly float[] _vertices4 = {
        0.3f, -0.3f, -0.3f, 0.0f, 0.0f, // face 4
        -0.3f, -0.3f, 0.3f, 1.0f, 1.0f,
        -0.3f, -0.3f, -0.3f, 1.0f, 0.0f,
        0.3f, -0.3f, 0.3f, 0.0f, 1.0f,
    };

    private readonly float[] _vertices5 = {
        0.3f, -0.3f, -0.3f, 0.0f, 0.0f, // face 5
        0.3f, 0.3f, 0.3f, 1.0f, 1.0f,
        0.3f, -0.3f, 0.3f, 1.0f, 0.0f,
        0.3f, 0.3f, -0.3f, 0.0f, 1.0f,
    };

    private readonly float[] _vertices6 = {
      -0.3f, -0.3f, 0.3f, 0.0f, 0.0f, // face 6 
      -0.3f, 0.3f, -0.3f, 1.0f, 1.0f,
      -0.3f, -0.3f, -0.3f, 1.0f, 0.0f,
      -0.3f, 0.3f, 0.3f, 0.0f, 1.0f,
    };

    private readonly uint[] _indices =
    {
        1, 2, 3, 0, 1, 3,
        3, 0, 1, 0, 2, 1,
        1, 0, 2, 3, 0, 5,
        1, 2, 3, 0, 1, 3,
        3, 2, 1, 0, 2, 6,
        1, 0, 2, 3, 0, 1
    };
    private Vector3 _lightPos = new Vector3(1.2f, 1.0f, 2.0f);
    private Shader _lampShader;
    private Shader _lightingShader;
    private int _vaoModel;
    private int _vaoLamp;
    private bool _lightingEnabled = false;
    private Camera _camera;

    public Mundo(GameWindowSettings gameWindowSettings, NativeWindowSettings nativeWindowSettings)
           : base(gameWindowSettings, nativeWindowSettings)
    {
      mundo = new Objeto(null, ref rotuloNovo);
    }

    private void Diretivas()
    {
#if DEBUG
      Console.WriteLine("Debug version");
#endif      
#if RELEASE
    Console.WriteLine("Release version");
#endif      
#if CG_Gizmo      
      Console.WriteLine("#define CG_Gizmo  // debugar gráfico.");
#endif
#if CG_OpenGL      
      Console.WriteLine("#define CG_OpenGL // render OpenGL.");
#endif
#if CG_DirectX      
      Console.WriteLine("#define CG_DirectX // render DirectX.");
#endif
#if CG_Privado      
      Console.WriteLine("#define CG_Privado // código do professor.");
#endif
      Console.WriteLine("__________________________________ \n");
    }

    protected override void OnLoad()
    {
      base.OnLoad();

      Diretivas();

      GL.ClearColor(0.0f, 0.0f, 0.0f, 1.0f);

      GL.Enable(EnableCap.DepthTest);       // Ativar teste de profundidade
      // GL.Enable(EnableCap.CullFace);     // Desenha os dois lados da face
      // GL.FrontFace(FrontFaceDirection.Cw);
      // GL.CullFace(CullFaceMode.FrontAndBack);

      #region Cores
      _shaderBranca = new Shader("Shaders/shader.vert", "Shaders/shaderBranca.frag");
      _shaderVermelha = new Shader("Shaders/shader.vert", "Shaders/shaderVermelha.frag");
      _shaderVerde = new Shader("Shaders/shader.vert", "Shaders/shaderVerde.frag");
      _shaderAzul = new Shader("Shaders/shader.vert", "Shaders/shaderAzul.frag");
      _shaderCiano = new Shader("Shaders/shader.vert", "Shaders/shaderCiano.frag");
      _shaderMagenta = new Shader("Shaders/shader.vert", "Shaders/shaderMagenta.frag");
      _shaderAmarela = new Shader("Shaders/shader.vert", "Shaders/shaderAmarela.frag");
      #endregion

      #region Objeto: Cubo
      objetoSelecionado = new Cubo(mundo, ref rotuloNovo);
      #endregion

      #region Face 1
      GL.Enable(EnableCap.Texture2D);
      _vertexArrayObject_texture = GL.GenVertexArray();
      GL.BindVertexArray(_vertexArrayObject_texture);

      _vertexBufferObject_texture = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject_texture);
      GL.BufferData(BufferTarget.ArrayBuffer, _vertices.Length * sizeof(float), _vertices, BufferUsageHint.StaticDraw);

      _elementBufferObject_texture = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject_texture);
      GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Length * sizeof(uint), _indices, BufferUsageHint.StaticDraw);

      _shader1 = new Shader("Shaders/shader.vert", "Shaders/shader.frag");
      _shader1.Use();

      var vertexLocation = _shader1.GetAttribLocation("aPosition");
      GL.EnableVertexAttribArray(vertexLocation);
      GL.VertexAttribPointer(vertexLocation, 3, VertexAttribPointerType.Float, false, 5 * sizeof(float), 0);

      var texCoordLocation = _shader1.GetAttribLocation("aTexCoord");
      GL.EnableVertexAttribArray(texCoordLocation);
      GL.VertexAttribPointer(texCoordLocation, 2, VertexAttribPointerType.Float, false, 5 * sizeof(float), 3 * sizeof(float));

      _texture1 = Texture.LoadFromFile("Textures/imagem6.jpg");
      _texture1.Use(TextureUnit.Texture0);

      #endregion

      #region Face 2
      GL.Enable(EnableCap.Texture2D);
      _vertexArrayObject_texture2 = GL.GenVertexArray();
      GL.BindVertexArray(_vertexArrayObject_texture2);

      _vertexBufferObject_texture2 = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject_texture2);
      GL.BufferData(BufferTarget.ArrayBuffer, _vertices2.Length * sizeof(float), _vertices2, BufferUsageHint.StaticDraw);

      _elementBufferObject_texture2 = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject_texture2);
      GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Length * sizeof(uint), _indices, BufferUsageHint.StaticDraw);

      _shader2 = new Shader("Shaders/shader.vert", "Shaders/shader.frag");
      _shader2.Use();

      var vertexLocation2 = _shader2.GetAttribLocation("aPosition");
      GL.EnableVertexAttribArray(vertexLocation);
      GL.VertexAttribPointer(vertexLocation, 3, VertexAttribPointerType.Float, false, 5 * sizeof(float), 0);

      var texCoordLocation2 = _shader2.GetAttribLocation("aTexCoord");
      GL.EnableVertexAttribArray(texCoordLocation);
      GL.VertexAttribPointer(texCoordLocation, 2, VertexAttribPointerType.Float, false, 5 * sizeof(float), 3 * sizeof(float));

      _texture2 = Texture.LoadFromFile("Textures/imagem4.jpg");
      _texture2.Use(TextureUnit.Texture0);

      #endregion

      #region Face 3
      GL.Enable(EnableCap.Texture2D);
      _vertexArrayObject_texture3 = GL.GenVertexArray();
      GL.BindVertexArray(_vertexArrayObject_texture3);

      _vertexBufferObject_texture3 = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject_texture3);
      GL.BufferData(BufferTarget.ArrayBuffer, _vertices3.Length * sizeof(float), _vertices3, BufferUsageHint.StaticDraw);

      _elementBufferObject_texture3 = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject_texture3);
      GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Length * sizeof(uint), _indices, BufferUsageHint.StaticDraw);

      _shader3 = new Shader("Shaders/shader.vert", "Shaders/shader.frag");
      _shader3.Use();

      var vertexLocation3 = _shader3.GetAttribLocation("aPosition");
      GL.EnableVertexAttribArray(vertexLocation);
      GL.VertexAttribPointer(vertexLocation, 3, VertexAttribPointerType.Float, false, 5 * sizeof(float), 0);

      var texCoordLocation3 = _shader3.GetAttribLocation("aTexCoord");
      GL.EnableVertexAttribArray(texCoordLocation);
      GL.VertexAttribPointer(texCoordLocation, 2, VertexAttribPointerType.Float, false, 5 * sizeof(float), 3 * sizeof(float));

      _texture3 = Texture.LoadFromFile("Textures/imagem7.jpeg");
      _texture3.Use(TextureUnit.Texture0);

      #endregion

      #region Face 4
      GL.Enable(EnableCap.Texture2D);
      _vertexArrayObject_texture4 = GL.GenVertexArray();
      GL.BindVertexArray(_vertexArrayObject_texture4);

      _vertexBufferObject_texture4 = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject_texture4);
      GL.BufferData(BufferTarget.ArrayBuffer, _vertices4.Length * sizeof(float), _vertices4, BufferUsageHint.StaticDraw);

      _elementBufferObject_texture4 = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject_texture4);
      GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Length * sizeof(uint), _indices, BufferUsageHint.StaticDraw);

      _shader4 = new Shader("Shaders/shader.vert", "Shaders/shader.frag");
      _shader4.Use();

      var vertexLocation4 = _shader4.GetAttribLocation("aPosition");
      GL.EnableVertexAttribArray(vertexLocation);
      GL.VertexAttribPointer(vertexLocation, 3, VertexAttribPointerType.Float, false, 5 * sizeof(float), 0);

      var texCoordLocation4 = _shader4.GetAttribLocation("aTexCoord");
      GL.EnableVertexAttribArray(texCoordLocation);
      GL.VertexAttribPointer(texCoordLocation, 2, VertexAttribPointerType.Float, false, 5 * sizeof(float), 3 * sizeof(float));

      _texture4 = Texture.LoadFromFile("Textures/imagem7.jpeg");
      _texture4.Use(TextureUnit.Texture0);

      #endregion

      #region Face 5
      GL.Enable(EnableCap.Texture2D);
      _vertexArrayObject_texture5 = GL.GenVertexArray();
      GL.BindVertexArray(_vertexArrayObject_texture5);

      _vertexBufferObject_texture5 = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject_texture5);
      GL.BufferData(BufferTarget.ArrayBuffer, _vertices5.Length * sizeof(float), _vertices5, BufferUsageHint.StaticDraw);

      _elementBufferObject_texture5 = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject_texture5);
      GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Length * sizeof(uint), _indices, BufferUsageHint.StaticDraw);

      _shader5 = new Shader("Shaders/shader.vert", "Shaders/shader.frag");
      _shader5.Use();

      var vertexLocation5 = _shader5.GetAttribLocation("aPosition");
      GL.EnableVertexAttribArray(vertexLocation);
      GL.VertexAttribPointer(vertexLocation, 3, VertexAttribPointerType.Float, false, 5 * sizeof(float), 0);

      var texCoordLocation5 = _shader5.GetAttribLocation("aTexCoord");
      GL.EnableVertexAttribArray(texCoordLocation);
      GL.VertexAttribPointer(texCoordLocation, 2, VertexAttribPointerType.Float, false, 5 * sizeof(float), 3 * sizeof(float));

      _texture5 = Texture.LoadFromFile("Textures/imagem1.jpg");
      _texture5.Use(TextureUnit.Texture0);

      #endregion
    
      #region Face 6
      GL.Enable(EnableCap.Texture2D);
      _vertexArrayObject_texture6 = GL.GenVertexArray();
      GL.BindVertexArray(_vertexArrayObject_texture6);

      _vertexBufferObject_texture6 = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject_texture6);
      GL.BufferData(BufferTarget.ArrayBuffer, _vertices6.Length * sizeof(float), _vertices6, BufferUsageHint.StaticDraw);

      _elementBufferObject_texture6 = GL.GenBuffer();
      GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject_texture5);
      GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Length * sizeof(uint), _indices, BufferUsageHint.StaticDraw);

      _shader6 = new Shader("Shaders/shader.vert", "Shaders/shader.frag");
      _shader6.Use();

      var vertexLocation6 = _shader6.GetAttribLocation("aPosition");
      GL.EnableVertexAttribArray(vertexLocation);
      GL.VertexAttribPointer(vertexLocation, 3, VertexAttribPointerType.Float, false, 5 * sizeof(float), 0);

      var texCoordLocation6 = _shader6.GetAttribLocation("aTexCoord");
      GL.EnableVertexAttribArray(texCoordLocation);
      GL.VertexAttribPointer(texCoordLocation, 2, VertexAttribPointerType.Float, false, 5 * sizeof(float), 3 * sizeof(float));

      _texture6 = Texture.LoadFromFile("Textures/imagem2.jpg");
      _texture6.Use(TextureUnit.Texture1);

      #endregion

      #region Cria retangulos

        Retangulo face1 = new Retangulo(objetoSelecionado, ref rotuloNovo, new Ponto4D(0.1, -0.1, -0.1), new Ponto4D(0.1, 0.1, 0.1), true);
        face1.shaderCor = _shader1;

        Retangulo face2 = new Retangulo(objetoSelecionado, ref rotuloNovo, new Ponto4D(-0.1, -0.1, -0.1), new Ponto4D(0.1, 0.1, -0.1), false);
        face2.shaderCor = _shader2;

        Retangulo face3 = new Retangulo(objetoSelecionado, ref rotuloNovo, new Ponto4D(-0.1, -0.1, -0.1), new Ponto4D(0.1, -0.1, 0.1), false);
        face3.shaderCor = _shader3;

        Retangulo face4 = new Retangulo(objetoSelecionado, ref rotuloNovo, new Ponto4D(-0.1, 0.1, -0.1), new Ponto4D(0.1, 0.1, 0.1), false);
        face4.shaderCor = _shader4;

        Retangulo face5 = new Retangulo(objetoSelecionado, ref rotuloNovo, new Ponto4D(-0.1, -0.1, 0.1), new Ponto4D(0.1, 0.1, 0.1), false);
        face5.shaderCor = _shader5;

        Retangulo face6 = new Retangulo(objetoSelecionado, ref rotuloNovo, new Ponto4D(-0.1, -0.1, -0.1), new Ponto4D(-0.1, 0.1, 0.1), true);
        face6.shaderCor = _shader6;

      #endregion

      _lightingShader = new Shader("Shaders/shader.vert", "Shaders/lighting.frag");
      _lampShader = new Shader("Shaders/shader.vert", "Shaders/shader.frag");

      {
        _vaoModel = GL.GenVertexArray();
        GL.BindVertexArray(_vaoModel);

        var positionLocation = _lightingShader.GetAttribLocation("aPos");
        GL.EnableVertexAttribArray(positionLocation);
        GL.VertexAttribPointer(positionLocation, 3, VertexAttribPointerType.Float, false, 6 * sizeof(float), 0);

        var normalLocation = _lightingShader.GetAttribLocation("aNormal");
        GL.EnableVertexAttribArray(normalLocation);
        GL.VertexAttribPointer(normalLocation, 3, VertexAttribPointerType.Float, false, 6 * sizeof(float), 3 * sizeof(float));
      }

      {
        _vaoLamp = GL.GenVertexArray();
        GL.BindVertexArray(_vaoLamp);

        var positionLocation = _lampShader.GetAttribLocation("aPos");
        GL.EnableVertexAttribArray(positionLocation);
        GL.VertexAttribPointer(positionLocation, 3, VertexAttribPointerType.Float, false, 6 * sizeof(float), 0);
      }

      _camera = new Camera(Vector3.UnitZ, Size.X / (float)Size.Y);

    }

    protected override void OnRenderFrame(FrameEventArgs e)
    {
      base.OnRenderFrame(e);

      GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

      mundo.Desenhar(new Transformacao4D(), _camera);

      #region face 1
      
        GL.BindVertexArray(_vertexArrayObject_texture);

        _texture1.Use(TextureUnit.Texture0);
        _shader1.Use();
        GL.DrawElements(PrimitiveType.Triangles, _indices.Length, DrawElementsType.UnsignedInt, 0);

      #endregion

      #region face 2
      
        GL.BindVertexArray(_vertexArrayObject_texture2);

        _texture2.Use(TextureUnit.Texture0);
        _shader2.Use();
        GL.DrawElements(PrimitiveType.Triangles, _indices.Length, DrawElementsType.UnsignedInt, 0);

      #endregion

      #region face 3
      
        GL.BindVertexArray(_vertexArrayObject_texture3);

        _texture3.Use(TextureUnit.Texture0);
        _shader3.Use();
        GL.DrawElements(PrimitiveType.Triangles, _indices.Length, DrawElementsType.UnsignedInt, 0);

      #endregion

      #region face 4
      
        GL.BindVertexArray(_vertexArrayObject_texture4);

        _texture4.Use(TextureUnit.Texture0);
        _shader4.Use();
        GL.DrawElements(PrimitiveType.Triangles, _indices.Length, DrawElementsType.UnsignedInt, 0);

      #endregion

      #region face 5
      
        GL.BindVertexArray(_vertexArrayObject_texture5);

        _texture5.Use(TextureUnit.Texture0);
        _shader5.Use();
        GL.DrawElements(PrimitiveType.Triangles, _indices.Length, DrawElementsType.UnsignedInt, 0);

      #endregion

      #region face 6
      
        GL.BindVertexArray(_vertexArrayObject_texture6);

        _texture6.Use(TextureUnit.Texture0);
        _shader6.Use();
        GL.DrawElements(PrimitiveType.Triangles, _indices.Length, DrawElementsType.UnsignedInt, 0);

      #endregion

      #region BasicLighting
      _lightingShader.Use();

      _lightingShader.SetMatrix4("model", Matrix4.Identity);
      _lightingShader.SetMatrix4("view", _camera.GetViewMatrix());
      _lightingShader.SetMatrix4("projection", _camera.GetProjectionMatrix());

      _lightingShader.SetVector3("objectColor", new Vector3(1.0f, 0.5f, 0.31f));
      _lightingShader.SetVector3("lightColor", new Vector3(1.0f, 1.0f, 1.0f));
      _lightingShader.SetVector3("lightPos", _lightPos);
      _lightingShader.SetVector3("viewPos", _camera.Position);

      GL.DrawArrays(PrimitiveType.Triangles, 0, 36);

      GL.BindVertexArray(_vaoLamp);

      _lampShader.Use();

      Matrix4 lampMatrix = Matrix4.CreateScale(0.2f);
      lampMatrix = lampMatrix * Matrix4.CreateTranslation(_lightPos);

      _lampShader.SetMatrix4("model", lampMatrix);
      _lampShader.SetMatrix4("view", _camera.GetViewMatrix());
      _lampShader.SetMatrix4("projection", _camera.GetProjectionMatrix());

      GL.DrawArrays(PrimitiveType.Triangles, 0, 36);
      #endregion

#if CG_Gizmo      
      Gizmo_Sru3D();
#endif
      SwapBuffers();
    }

    protected override void OnUpdateFrame(FrameEventArgs e)
    {
      base.OnUpdateFrame(e);

      // ☞ 396c2670-8ce0-4aff-86da-0f58cd8dcfdc   TODO: forma otimizada para teclado.
      #region Teclado
      var input = KeyboardState;
      if (input.IsKeyDown(Keys.Escape))
        Close();
      const float cameraSpeed = 1.5f;

      if (input.IsKeyDown(Keys.Z))
        _camera.Position = Vector3.UnitZ;
      if (input.IsKeyDown(Keys.W))
        _camera.Position += _camera.Front * cameraSpeed * (float)e.Time; // Forward
      if (input.IsKeyDown(Keys.S))
        _camera.Position -= _camera.Front * cameraSpeed * (float)e.Time; // Backwards
      if (input.IsKeyDown(Keys.A))
        _camera.Position -= _camera.Right * cameraSpeed * (float)e.Time; // Left
      if (input.IsKeyDown(Keys.D))
        _camera.Position += _camera.Right * cameraSpeed * (float)e.Time; // Right
      if (input.IsKeyDown(Keys.RightShift))
        _camera.Position += _camera.Up * cameraSpeed * (float)e.Time; // Up
      if (input.IsKeyDown(Keys.LeftShift))
        _camera.Position -= _camera.Up * cameraSpeed * (float)e.Time; // Down
      if (input.IsKeyDown(Keys.H))
        _camera.Pitch += -0.5f;
      if (input.IsKeyDown(Keys.Y))
        _camera.Pitch += 0.5f;
      if (input.IsKeyDown(Keys.G))
        _camera.Yaw += -0.5f;
      if (input.IsKeyDown(Keys.J))
        _camera.Yaw += 0.5f;
      #endregion

      #region  Iluminação
      if (input.IsKeyDown(Keys.D1))
        _lightingEnabled = !_lightingEnabled;
      #endregion


      #region  Mouse

      if (MouseState.IsButtonPressed(MouseButton.Left))
      {
        xAnterior = MouseState.X;
        yAnterior = MouseState.Y;
      }
      if (MouseState.IsButtonDown(MouseButton.Left))
      {
        float incrementoHorizontal = (xAnterior - MouseState.X) * 0.005f;
        float incrementoVertical = (yAnterior - MouseState.Y) * 0.005f;
        anguloHorizontal += incrementoHorizontal;
        anguloVertical += incrementoVertical;

        _camera.MoveCamera(anguloHorizontal, anguloVertical, incrementoHorizontal, incrementoVertical);

      }
      if (MouseState.IsButtonDown(MouseButton.Right) && objetoSelecionado != null)
      {
        System.Console.WriteLine("MouseState.IsButtonDown(MouseButton.Right)");

        int janelaLargura = Size.X;
        int janelaAltura = Size.Y;
        Ponto4D mousePonto = new Ponto4D(MousePosition.X, MousePosition.Y);
        Ponto4D sruPonto = Utilitario.NDC_TelaSRU(janelaLargura, janelaAltura, mousePonto);

        objetoSelecionado.PontosAlterar(sruPonto, 0);
      }
      if (MouseState.IsButtonReleased(MouseButton.Right))
      {
        System.Console.WriteLine("MouseState.IsButtonReleased(MouseButton.Right)");
      }


      #endregion

    }

    protected override void OnResize(ResizeEventArgs e)
    {
      base.OnResize(e);

      GL.Viewport(0, 0, Size.X, Size.Y);
    }

    protected override void OnUnload()
    {
      mundo.OnUnload();

      GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
      GL.BindVertexArray(0);
      GL.UseProgram(0);

      GL.DeleteBuffer(_vertexBufferObject_sruEixos);
      GL.DeleteVertexArray(_vertexArrayObject_sruEixos);

      GL.DeleteProgram(_shaderBranca.Handle);
      GL.DeleteProgram(_shaderVermelha.Handle);
      GL.DeleteProgram(_shaderVerde.Handle);
      GL.DeleteProgram(_shaderAzul.Handle);
      GL.DeleteProgram(_shaderCiano.Handle);
      GL.DeleteProgram(_shaderMagenta.Handle);
      GL.DeleteProgram(_shaderAmarela.Handle);

      base.OnUnload();
    }

#if CG_Gizmo
    private void Gizmo_Sru3D()
    {
#if CG_OpenGL && !CG_DirectX
      var model = Matrix4.Identity;
      GL.BindVertexArray(_vertexArrayObject_sruEixos);
      // EixoX
      _shaderVermelha.SetMatrix4("model", model);
      _shaderVermelha.SetMatrix4("view", _camera.GetViewMatrix());
      _shaderVermelha.SetMatrix4("projection", _camera.GetProjectionMatrix());
      _shaderVermelha.Use();
      GL.DrawArrays(PrimitiveType.Lines, 0, 2);
      // EixoY
      _shaderVerde.SetMatrix4("model", model);
      _shaderVerde.SetMatrix4("view", _camera.GetViewMatrix());
      _shaderVerde.SetMatrix4("projection", _camera.GetProjectionMatrix());
      _shaderVerde.Use();
      GL.DrawArrays(PrimitiveType.Lines, 2, 2);
      // EixoZ
      _shaderAzul.SetMatrix4("model", model);
      _shaderAzul.SetMatrix4("view", _camera.GetViewMatrix());
      _shaderAzul.SetMatrix4("projection", _camera.GetProjectionMatrix());
      _shaderAzul.Use();
      GL.DrawArrays(PrimitiveType.Lines, 4, 2);

#elif CG_DirectX && !CG_OpenGL
      Console.WriteLine(" .. Coloque aqui o seu código em DirectX");
#elif (CG_DirectX && CG_OpenGL) || (!CG_DirectX && !CG_OpenGL)
      Console.WriteLine(" .. ERRO de Render - escolha OpenGL ou DirectX !!");
#endif
    }
#endif    

  }
}
